package com.example.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button a = findViewById(R.id.button);
        //انادي الedit text
        final EditText nam = findViewById(R.id.editTextTextPersonName);
        final EditText age = findViewById(R.id.editText9);
        final EditText number = findViewById(R.id.editText8);
        final EditText email = findViewById(R.id.editText6);
        final EditText address = findViewById(R.id.editText5);




        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //اضيف ال getText.toString
                String namstring = nam.getText().toString();
                String agestrimg = age.getText().toString();
                String numberstring = number.getText().toString();
                String emailstring = email.getText().toString();
                String addrestring= address.getText().toString();


                Intent b = new Intent(MainActivity.this, MainActivity2.class);
                b.putExtra("information na", namstring);
                b.putExtra("information ag", agestrimg);
                b.putExtra("information nu", numberstring);
                b.putExtra("information em", emailstring);
                b.putExtra("information ad", addrestring );
                startActivity(b);

            }
        });
    }
}