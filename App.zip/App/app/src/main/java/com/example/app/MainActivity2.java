package com.example.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.os.Handler;


public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        TextView elnam = findViewById(R.id.textView4);
        TextView elhii = findViewById(R.id.textView5);
        TextView elage = findViewById(R.id.textView6);
        TextView elnum = findViewById(R.id.textView12);
        TextView elema = findViewById(R.id.textView14);
        TextView eladd = findViewById(R.id.textView17);
        Button o = findViewById(R.id.button2);



        Bundle aj = getIntent().getExtras();
        String name = aj.getString("information na");
        String age = aj.getString("information ag");
        final String number = aj.getString("information nu");
        String email = aj.getString("information em");
        String address = aj.getString("information ad");


        elhii.setText(" hi "+ name + "  هذه معلوماتك الشخصية");

        elnam.setText(name);
        elage.setText(age);
        elnum.setText(number);
        elema.setText(email);
        eladd.setText(address);

        o.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent y = new Intent( MainActivity2.this, MainActivity.class);
                startActivity(y);
            }
        });

        elema.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
                emailIntent.setType("plain/text");
                startActivity(emailIntent);
            }
        });

        elnum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialPhoneNumber();
            }

            private void dialPhoneNumber() {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:" + number));
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                }
            }
        });

        eladd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Uri gmmIntentUri = Uri.parse("geo:0,0?q=");
                        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                        mapIntent.setPackage("com.google.android.apps.maps");
                        startActivity(mapIntent);
                    }
                }, 1000);
            }
        });
    }
}